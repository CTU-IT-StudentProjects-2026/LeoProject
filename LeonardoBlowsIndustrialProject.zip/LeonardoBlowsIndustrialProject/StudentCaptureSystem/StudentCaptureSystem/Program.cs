﻿using System;
using System.ComponentModel.DataAnnotations;

//first commit
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("---Student Profile Processor---");

        Console.Write("Enter Student Name: ");
        string name = Console.ReadLine();

        double mark1 = GetValidMark("Enter Subject 1 mark: ");
        double mark2 = GetValidMark("Enter Subject 2 mark: ");
        double mark3 = GetValidMark("Enter Subject 3 mark: ");

        double total = CalculateTotal(mark1,  mark2, mark3);
        double average = CalculateAverage(total);

        string result = GetResult(average);

        DisplayOutput(name, total, average, result);
        Console.WriteLine();
    }

    static double GetValidMark(string message)
    {
        double mark;
        while (true)
        {
            Console.Write(message);
            if (double.TryParse(Console.ReadLine(), out mark) && mark >= 0 && mark <= 100)
            {
                return mark;
            }
            else
            {
                Console.WriteLine("Invalid Input Enter a number between 0 to 100. ");
            }
        }
    }

    static double CalculateTotal(double a, double b, double c)
    {
        return a + b + c;
    }
    static double CalculateTotal(double a, double b)
    {
        return a + b;
    }
    static double CalculateAverage(double total)
    {
        return total / 3;
    }
    static string GetResult(double average)
    {
        return average >= 50 ? "PASS" : "FAIL";
    }

    static void DisplayOutput(String name, double total, double average, string result)
    {
        Console.WriteLine("\n--- Student Results --- ");
        Console.WriteLine($"Name: {name} ");
        Console.WriteLine($"Total: {total} ");
        Console.WriteLine($"Average: {average:F2} ");
        Console.WriteLine($"Result: {result} ");
    }
}