namespace CaptureForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalulate_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;

            if (double.TryParse(txtM1.Text, out double m1) &&
                double.TryParse(txtM1.Text, out double m2) &&
                double.TryParse(txtM1.Text, out double m3))
            {
                double total = m1 + m2 + m3;
                double avg = total / 3;

                string result = avg >= 50 ? "PASS" : "FAIL";

                lblOutput.Text = $"Name: {name}\nTotal: {total}\nAverage: {avg:F2}\nResult: {result}";
            }
            else
            {
                MessageBox.Show("Enter valid numbers!");
            }
        }
    }
}
