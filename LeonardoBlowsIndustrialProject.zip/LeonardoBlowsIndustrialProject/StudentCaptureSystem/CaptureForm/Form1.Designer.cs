﻿namespace CaptureForm
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtM1 = new TextBox();
            txtM2 = new TextBox();
            txtM3 = new TextBox();
            btnCalulate = new Button();
            lblOutput = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(21, 25);
            label1.Name = "label1";
            label1.Size = new Size(83, 15);
            label1.TabIndex = 0;
            label1.Text = "Student Name";
            // 
            // txtName
            // 
            txtName.Location = new Point(24, 55);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 96);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 2;
            label2.Text = "Mark 1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 144);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 3;
            label3.Text = "Mark 2";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 188);
            label4.Name = "label4";
            label4.Size = new Size(46, 15);
            label4.TabIndex = 4;
            label4.Text = "Mark 3 ";
            // 
            // txtM1
            // 
            txtM1.Location = new Point(24, 114);
            txtM1.Name = "txtM1";
            txtM1.Size = new Size(100, 23);
            txtM1.TabIndex = 5;
            // 
            // txtM2
            // 
            txtM2.Location = new Point(24, 162);
            txtM2.Name = "txtM2";
            txtM2.Size = new Size(100, 23);
            txtM2.TabIndex = 6;
            // 
            // txtM3
            // 
            txtM3.Location = new Point(24, 206);
            txtM3.Name = "txtM3";
            txtM3.Size = new Size(100, 23);
            txtM3.TabIndex = 7;
            // 
            // btnCalulate
            // 
            btnCalulate.Location = new Point(25, 259);
            btnCalulate.Name = "btnCalulate";
            btnCalulate.Size = new Size(75, 23);
            btnCalulate.TabIndex = 8;
            btnCalulate.Text = "Calculate";
            btnCalulate.UseVisualStyleBackColor = true;
            btnCalulate.Click += btnCalulate_Click;
            // 
            // lblOutput
            // 
            lblOutput.AutoSize = true;
            lblOutput.Location = new Point(27, 315);
            lblOutput.Name = "lblOutput";
            lblOutput.Size = new Size(0, 15);
            lblOutput.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblOutput);
            Controls.Add(btnCalulate);
            Controls.Add(txtM3);
            Controls.Add(txtM2);
            Controls.Add(txtM1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtName;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtM1;
        private TextBox txtM2;
        private TextBox txtM3;
        private Button btnCalulate;
        private Label lblOutput;
    }
}
